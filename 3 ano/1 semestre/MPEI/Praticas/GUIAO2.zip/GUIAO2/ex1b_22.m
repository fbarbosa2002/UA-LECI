x2 = 1:6 ;
sx = [1,2,3,4,5,6];
y2 = cumsum(sx) ;

stairs(x2,y2) ;