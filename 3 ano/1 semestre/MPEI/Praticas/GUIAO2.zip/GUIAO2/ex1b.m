%ex2

% valor teórico = numero de casos favoráveis/ numero de casos possiveis
% valor teórico = 3/4

% casos possiveis =(MM,MF,FF,FM)