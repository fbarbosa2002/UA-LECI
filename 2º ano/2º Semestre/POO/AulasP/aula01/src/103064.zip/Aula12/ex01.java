package Aula12;
import java.util.Scanner;
import java.io.FileReader;
import java.io.IOException;
import java.util.Set;
import java.util.TreeSet;


public class ex01 {
    public static void main (String [] args) throws IOException{
        Set<String> palavras = new TreeSet<>();
        int numero_palavras = 0;
        FileReader file_reader = new FileReader("teste.txt");
        Scanner file_scanner = new Scanner(file_reader);
        String temp_palavras = "";

        while (file_scanner.hasNext()) temp_palavras = temp_palavras + " " + file_scanner.next();
        file_scanner.close(); 
        file_reader.close();
        temp_palavras = temp_palavras.toLowerCase().replaceAll("[\\t\\n\\.\\,\\:\\'\\‘\\’\\;\\?\\!\\-\\*\\{\\}\\=\\+\\&\\/\\\\(\\)\\[\\]\\”\\“\\\"\\']", " ").trim();
        
        
        for (String palavra : temp_palavras.split("\\s+")) {
            palavras.add(palavra);
            numero_palavras++;
        }
        
        System.out.println("Numero total de palavras: " + numero_palavras);
        System.out.println("Numero de diferentes palavras: " + palavras.size());
    }
}
