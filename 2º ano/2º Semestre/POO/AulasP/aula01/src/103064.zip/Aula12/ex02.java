package Aula12;


import java.io.FileReader;
import java.io.IOException;
import java.util.SortedSet;
import java.util.Scanner;
import java.util.TreeSet;

public class ex02 {
    public static void main(String [] args) throws IOException{
        SortedSet<Movie> movie= gerarlista("movies.txt");
       
        System.out.println(">>>> Filmes por ordem alfabetica <<<<");
        for (Movie movies : movie) {
            System.out.println(movies.toString());
        }
        
    }

    public static SortedSet<Movie> gerarlista( String cam) throws IOException{

        FileReader file_read= new FileReader(cam);
        Scanner file_scanner = new Scanner(file_read);
        SortedSet<Movie> conj= new TreeSet<>();

        file_scanner.nextLine();

        while(file_scanner.hasNextLine()){
            String line= file_scanner.nextLine();
            String[] array= line.split("\t");
            conj.add(new Movie(array[0], Float.parseFloat(array[1]),array[2],array[3],Integer.parseInt(array[4])));
        }
        file_scanner.close();
        file_read.close();
        return conj;
    }
}
