package Aula12;

public  class Movie implements Comparable<Movie>{
    private String name, avaliation, gender;
    private float point;
    private int duration;
    
    public Movie(String name, float point, String avaliation, String gender, int duration){
        this.name=name;
        this.avaliation=avaliation;
        this.gender=gender;
        this.point=point;
        this.duration=duration;
    }
    public String getName(){
        return name;
    }
    public String getAvaliation(){
        return avaliation;
    }
    public String getGender(){
        return gender;
    } 
    public float getPoint(){
        return point;
    }
    public int getDuration(){
        return duration;
    }
    @Override public String toString() {
        return "Filme{" + "nome=" + name + ", pontuacao=" + point + ", classificacao=" + avaliation + ", genero=" + gender + ", duracao=" + duration + '}';
    }
    @Override public int compareTo(Movie o) {
        return this.getName().toLowerCase().compareTo(o.getName().toLowerCase());
    }
}
