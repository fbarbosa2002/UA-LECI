package Treino_Teste.Teste;

public class Activity {
    private int participants;

    public Activity(int participants) {
        this.participants = participants;
    }

    public int getParticipants() {
        return participants;
    }

    public void setParticipants(int participants) {
        this.participants = participants;
    }
    
}
