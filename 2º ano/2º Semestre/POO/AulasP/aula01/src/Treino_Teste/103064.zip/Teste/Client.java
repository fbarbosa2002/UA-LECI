package Treino_Teste.Teste;

public class Client {
    private String nome,localidade;

    public Client(String nome, String localidade) {
        this.nome = nome;
        this.localidade = localidade;
    }

    public String getNome() {
        return nome;
    }
    public Client addClient(String nome, String localidade) {
        Client cliente= new Client(nome,localidade);
        return cliente;

    }
    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getLocalidade() {
        return localidade;
    }

    public void setLocalidade(String localidade) {
        this.localidade = localidade;
    }

    @Override
    public String toString() {
        return nome +"[" + localidade + "]\n";
    }
    
}
