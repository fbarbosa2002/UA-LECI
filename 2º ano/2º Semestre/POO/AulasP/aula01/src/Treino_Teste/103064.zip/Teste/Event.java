
package Treino_Teste.Teste;

import java.util.LinkedList;
import java.util.List;
import java.time.LocalDate;

public class Event implements IEvent {
    protected String data;
    protected List<Activity> lista;

    
    public Event() {
        this.lista=new LinkedList<>();
        
    }

    public LocalDate getDate(){
        return LocalDate.parse(data);
    }
    public double totalCost(){
        return 0;
    }
    public Event addActivity(Activity activity){
        Event evento= new Event();
        lista.add(activity);
        return evento;
    }

    @Override
    public String toString() {
        return "Events:\n" +  data + ", lista=" + lista + "]";
    }
    
}
