package Treino_Teste.Teste;

public class Sport extends Activity{
    public enum Modality{
        HIKING, BIKE, BOWLING,KAYAK;
    }
    public Sport(Modality modalidades,int part){
        super(part);
    }
}
