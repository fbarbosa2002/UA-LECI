package Treino_Teste.Teste;

public class Culture extends Activity {
   public enum Option{
    ART_MUSEUM,RIVER_TOUR,ARCHITECTURAL_TOUR,WINE_TASTING;
   }

public Culture(Option modalidades,int participants) {
    super(participants);
}
   
}
