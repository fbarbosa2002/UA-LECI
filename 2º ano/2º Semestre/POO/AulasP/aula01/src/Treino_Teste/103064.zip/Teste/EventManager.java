package Treino_Teste.Teste;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

public class EventManager {
    private String nome;
    private Set<Client> clientes;
    private Set<Event> eventos;
    public EventManager(String nome) {
        this.nome = nome;
        this.clientes= new HashSet<>();
        this.eventos= new HashSet<>();
    }
    public Client addClient(String nome, String localidade) {
        Client cliente= new Client(nome,localidade);
        clientes.add(cliente);
        return cliente;

    }
    public Event addEvent(Client a, LocalDate c){
       Event evento=new Event();
       eventos.add(evento);
       
        return evento;
       
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    public String listClients(){
        String string="";
        for(Client a: clientes){
            string+=a.toString();
        }
        return string;
    }
    public String listEvents(){
        String string="";
        for(Event a: eventos ){
            string += a.toString();
        }
        return string;
    }

}
