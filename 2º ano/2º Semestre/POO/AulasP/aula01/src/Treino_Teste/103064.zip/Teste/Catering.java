package Treino_Teste.Teste;


public class Catering extends Activity{
    public enum Option{
        LIGHT_BITES,FULL_MENU,DRINKS_AND_SNACKS;
    } 
    public Catering(Option option, int part) {
        super(part);
    }


   
}
    
